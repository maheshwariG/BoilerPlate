const mockStyle = {};
export default mockStyle;
