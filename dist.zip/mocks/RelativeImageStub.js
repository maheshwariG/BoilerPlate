const mockFile = 'test-file-stub';
export default mockFile;
