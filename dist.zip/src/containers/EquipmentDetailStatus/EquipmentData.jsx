import React from 'react';
const EquipmentData = () => {
  console.log('child');
  return <div>Test</div>;
};
export default EquipmentData;
