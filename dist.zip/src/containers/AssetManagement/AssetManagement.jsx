import React from 'react';
import AssetManagementComp from '../../components/AssetManagement/AssetManagement';
const AssetManagement = () => {
  return <AssetManagementComp />;
};
export default AssetManagement;
