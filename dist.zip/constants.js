export const EquipmentStatus = 'EquipmentStatus';
export const AssetManagementTab = 'AssetManagement';
